<!--
function listFilter(id)
{
	alert(document.getElementById(id).valu);
	return null;
}

//-->